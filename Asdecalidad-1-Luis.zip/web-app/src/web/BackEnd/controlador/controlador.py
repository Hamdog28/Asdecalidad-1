
class sujeto:
    def __init__(self):
        self.vector=[]
        
    def leerCarpetas(self):
        return []
    def leerImagenes(self):
        return []